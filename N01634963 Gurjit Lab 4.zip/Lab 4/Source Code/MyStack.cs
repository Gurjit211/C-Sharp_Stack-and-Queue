﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Part2
{
    public class MyStack
    {// Private members to store the stack items and track the top of the stack
        private ArrayList stackItems;
        private int top;

        // Constructor to initialize the stack
        public MyStack()
        {
            stackItems = new ArrayList();
            top = -1;
        }

        // Property to get the count of items in the stack
        public int Count
        {
            get { return stackItems.Count; }
        }

        // Method to push an item onto the stack
        public void Push(object item)
        {
            stackItems.Add(item);
            top++;
        }

        // Method to pop an item off the stack
        public object Pop()
        {
            if (top < 0)
                throw new InvalidOperationException("Stack is empty.");

            object item = stackItems[top];
            stackItems.RemoveAt(top);
            top--;
            return item;
        }

        // Method to peek at the top item of the stack without removing it
        public object Peek()
        {
            if (top < 0)
                throw new InvalidOperationException("Stack is empty.");

            return stackItems[top];
        }

        // Method to clear the stack
        public void Clear()
        {
            stackItems.Clear();
            top = -1;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Example usage of MyStack class
            MyStack stack = new MyStack();
            stack.Push(93);
            stack.Push(5911);
            stack.Push(47);
            stack.Push(295);
            stack.Push(410);
            stack.Push(6);
            stack.Push(11);

            Console.WriteLine("Count of my stack is: " + stack.Count); 

            Console.WriteLine("Popped item @ top item: " + stack.Pop());
            Console.WriteLine("Count of stack items after pop: " + stack.Count);

            stack.Clear();
            Console.WriteLine("Count of stack  after clear: " + stack.Count);
        }

    }
}
