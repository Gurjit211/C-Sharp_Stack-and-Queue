﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> animalsQueue = new Queue<string>();

            animalsQueue.Enqueue("Cow");
            animalsQueue.Enqueue("Cat");
            animalsQueue.Enqueue("Lion");
            animalsQueue.Enqueue("Zebra");
            animalsQueue.Enqueue("Tiger");
            animalsQueue.Enqueue("Goat");

            string dequeuedAnimal = animalsQueue.Dequeue();
            Console.WriteLine("Dequeued: " + dequeuedAnimal);

            
            string nextAnimal = animalsQueue.Peek();
            Console.WriteLine("Next animal: " + nextAnimal);

            
            Console.WriteLine("Number of animals in queue: " + animalsQueue.Count);

            // Clear the queue
            animalsQueue.Clear();
            Console.WriteLine("Number of animals in queue after clearing: " + animalsQueue.Count);

        }
    }
}
